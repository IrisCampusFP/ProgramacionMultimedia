using UnityEngine;

public class PipeController : MonoBehaviour
{
    public float speed;

    // Variable que representa el l�mite en x en el que la tuber�a debe desaparecer y aparecer al lado contrario
    public float xLimit;

    // Variable que representa el m�nimo y m�ximo de altura de la tuber�a
    public float yVariance;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.x < -xLimit)
        {
            // Genero un n�mero aleatorio de altura para la tuber�a dentro del rango de los l�mites m�nimo y m�ximo
            float alturaAleatoria = Random.Range(-yVariance, yVariance);
            transform.position = new Vector3(xLimit, alturaAleatoria, 0.0f);
            //tuberiasPasadas++;
        }
        transform.position += new Vector3(-speed * Time.deltaTime, 0.0f, 0.0f);
    }
}
